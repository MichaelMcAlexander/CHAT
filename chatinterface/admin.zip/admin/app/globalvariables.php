<?php 

$loggedin = false;