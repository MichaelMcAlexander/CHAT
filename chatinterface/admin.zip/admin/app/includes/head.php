<!--head document to add to each html file-->
<meta charset="UTF-8">
<title>Chat Admin</title>
<link href='http://fonts.googleapis.com/css?family=Muli' rel='stylesheet'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet'>
<link rel="stylesheet" href="css/main.css">

<meta name="viewport" content="width=device-width, initial-scale=1.0">