<header id="header">
	<h2>Chat Administrator Login</h2>
	<span>Go to <a href="http://www.chatrichmond.org">Chat Richmond</a> website</span>
</header>
<div class="login-wrapper">
	<div class="logo-wrapper">
		<img id="logo" src="http://static.squarespace.com/static/53ffb114e4b0d8bec9d56696/t/5402b275e4b0cf67d96ba0f7/1417548429808/?format=1500w" alt="">
	</div>
	<div class="login">
		<form action="login.php" method="post">
			<label>
				<input type="text" name="  username" placeholder="username" autocomplete="off" >
			</label>
			<label>
				<input type="password" name="  password" placeholder="password">
			</label>
			<label>
				<input type="submit" value="login">
			</label>
		</form>
	</div>
</div>