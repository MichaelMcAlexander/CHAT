<?php 

$loggedin = false;

header('Location: index.php');