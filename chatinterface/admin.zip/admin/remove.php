<?php 

require_once 'app/init.php';

echo 'This feature is coming soon!';