// This is the main page of the application. Users can make a selection to go to other windows or pages from here


var tabGroup = Ti.UI.createTabGroup({
	tabsBackgroundColor:'#334553',
	color:'white',
});

var win1 = Ti.UI.createWindow
({
	backgroundColor: 'white'
});

// church hill academy window
var win12 = Ti.UI.createWindow({
	
	backgroundColor: 'white'
	
});

//tiny tykes window
var win11 = Ti.UI.createWindow({
	backgroundColor: 'white'
	
});

var image = Ti.UI.createImageView
(
	{
		image: 'CHATlogo.jpg',
		width: '80%',
		height: '18%',
		top: 0,
		left: '5%'
		
	}
);


    

var view_student = Ti.UI.createView({
  backgroundColor:'#D7D7D7',
  top:'57%',
  height: '8%',
  width: '93%'

});

var label_student = Titanium.UI.createLabel({
	color:'#020202',
	text:'Student',
	font:{fontSize:'15dp'},
	left: '6%'
	
});

view_student.add(label_student);

view_student.addEventListener('click',function(e)
{	
		var win_student = Ti.UI.createWindow({
			url: 'student.js',
			backgroundColor: 'white',
			title:'Student'
		});
		
		// win_student.student_Announcement = studentMsg;
		
		tab1.open(win_student);	   
});

var view_parent = Ti.UI.createView
({
  backgroundColor:'#D7D7D7',
  top:'66%',
  height: '8%',
  width: '93%'
});

var label_parent = Titanium.UI.createLabel
({
	color:'#020202',
	text:'Parent',
	font:{fontSize:'15dp'},
	left: '6%'		
});

view_parent.add(label_parent);

view_parent.addEventListener('click',function(e)
{
		var win_parent = Ti.UI.createWindow({
			url: 'parent.js',
			backgroundColor: 'white',
			title:'Parent'
		});
		
		
		
		tab1.open(win_parent);	   
});

var view_volunteer = Ti.UI.createView({
  backgroundColor:'#D7D7D7',
  top:'75%',
  height: '8%',
  width: '93%'

});

var label_volunteer = Titanium.UI.createLabel({
	color:'#020202',
	text:'Volunteer',
	font:{fontSize:'15dp'},
	left: '6%'
});

view_volunteer.add(label_volunteer);

view_volunteer.addEventListener('click',function(e)
{
	
		var win_volunteer = Ti.UI.createWindow({
			url: 'volunteer.js',
			backgroundColor: 'white',
			title:'Volunteer'
		});
		
		
		tab1.open(win_volunteer);	  
		
		
	
	   
});


var view_title = Ti.UI.createView({
  backgroundColor:'#B69A69',
  top:'18%',
  height: '6.5%',
  width: '93%'

});

var label_title = Titanium.UI.createLabel({
	color:'#FEFEFE',
	text:'ANNOUNCEMENTS',
	font:{fontSize:'16dp',fontWeight:'bold'},
	
});

view_title.add(label_title);

var main_announcement = Titanium.Network.createHTTPClient();
main_announcement.onload = function()
{
   var json = this.responseText;
    
         
   var post1 = JSON.parse(json);
    var announcements = [];
   
 for(var i =0;i<post1.length;i++){ 
 	announcements[i] = post1[i];
}
    
 


var scrollViewMain = Ti.UI.createScrollView({
  showVerticalScrollIndicator: true,
  showHorizontalScrollIndicator: false,
    top: '25%',
	bottom: '52%',
	left: '3%',
	right: '3%'
 
});

var viewMain = Ti.UI.createView({
  backgroundColor:'#F3E5D0',

});

for(var i=0;i<100;i++)
{
	if(announcements[i]==null)
	{
		
	
          announcements[i]= '';
     }
     
}

var label_announcementsMain = Titanium.UI.createLabel
({
	color:'black',	
	 text: announcements[0] + '\n' +  announcements[1] + '\n' +  announcements[2] + '\n' +  announcements[3] + '\n' +
     announcements[4] + '\n' +  announcements[5]+ '\n' +  announcements[6]+ '\n' +  announcements[7]+ '\n' +  announcements[8],
	font:{fontSize:'15dp'},
	left:'3%'
	
});

viewMain.add(label_announcementsMain);
scrollViewMain.add(viewMain);
win1.add(scrollViewMain);

};

//main_announcement.open("GET","http://192.168.1.3/CHAT/main_announcement.php");


main_announcement.open("GET","http://testdemo.web44.net/CHAT/main_announcement.php");



main_announcement.send();

// announcement title for CHA
var view_title_CHA = Ti.UI.createView({
  backgroundColor:'#E9E9E9',
  top:'21%',
  height: '7%',
  width: '93%'

});

var Label_announcement1 = Ti.UI.createLabel({
    text : "ANNOUNCEMENTS",
    font:{
        fontSize : '16dp',
        fontWeight : 'bold',
        fontFamily:'Helvetica Neue'
        
    },
    color : 'black',
    
    
    
});

view_title_CHA.add(Label_announcement1);


// creates a label containing the link to the CHAT website
var label6 = Titanium.UI.createLabel({
	color:'#A6252F',
	text:'www.chatrichmond.org',
	font:{fontSize:'15dp',fontFamily:'Helvetica Neue'},
	
	top: '93%'	
});

label6.addEventListener('click', function(e) {
    
    Titanium.Platform.openURL('http://www.chatrichmond.org');
});

var labelPhone = Titanium.UI.createLabel(
	{
		text: '(804) 236-4964',
		color:'#A6252F',
	    font:{fontSize:'15dp',fontFamily:'Helvetica Neue'},
	    top: '87%',
	   
		
	}
);

labelPhone.addEventListener("click",function(event){
    Titanium.Platform.openURL('tel:8042364964');
});




// Announcement title for Tiny Tykes
var view_title2 = Ti.UI.createView({
  backgroundColor:'#E9E9E9',
  top:'21%',
  height: '7%',
  width: '93%'

});

var Label_announcement2 = Ti.UI.createLabel({
    text : "ANNOUNCEMENTS",
    font:{
        fontSize : '16dp',
        fontWeight : 'bold',
        fontFamily:'Helvetica Neue'
        
    },
    color : 'black',
    
    
    
});

view_title2.add(Label_announcement2);

// Announcement title for after school
var view_title3 = Ti.UI.createView({
  backgroundColor:'#E9E9E9',
  top:'21%',
  height: '7%',
  width: '93%'

});

var Label_announcement3 = Ti.UI.createLabel({
    text : "ANNOUNCEMENTS",
    font:{
        fontSize : '16dp',
        fontWeight : 'bold',
        fontFamily:'Helvetica Neue'
        
    },
    color : 'black',
    
    
    
});

view_title3.add(Label_announcement3);


// creates a main tab
var tab1 = Ti.UI.createTab({
	title: 'Main',
	
	
	window: win1
});

//imports a image logo from the designated folder
var image3 = Ti.UI.createImageView(
	{
		image: 'afterSchool.JPG',
		width: '85%',
		height: '16%',
		top: '1%',
		left: '5%'
	}
);
var afterSchool_announcement = Titanium.Network.createHTTPClient();
afterSchool_announcement.onload = function()
{
   var json = this.responseText;
    
         
   var post1 = JSON.parse(json);
    var announcements = [];
 
 for(var i =0;i<post1.length;i++){ 
 	announcements[i] = post1[i];
}  
 
var scrollView1 = Ti.UI.createScrollView({
  showVerticalScrollIndicator: true,
  showHorizontalScrollIndicator: false,
    top: '28%',
	bottom: '15%',
	left: '3%',
	right: '3%'
 
});

var view1 = Ti.UI.createView({
  backgroundColor:'white',

});

for(var i=0;i<100;i++)
{
	if(announcements[i]==null)
	{
		
	
          announcements[i]= '';
     }
     
}

// displays the after school announcements on its window
var label_afterSchool = Titanium.UI.createLabel
({
	left:'2%',
	top:'2%',
	color:'black',	
    text: announcements[0] + '\n\n' +  announcements[1] + '\n\n' +  announcements[2] + '\n\n' +  announcements[3] + '\n\n' +
     announcements[4] + '\n\n' +  announcements[5]+ '\n\n' +  announcements[6]+ '\n\n' +  announcements[7]+ '\n\n' +  announcements[8],
	
	font:{fontSize:'15dp',fontFamily:'Helvetica Neue'},
	
	
});


view1.add(label_afterSchool);
scrollView1.add(view1);
win10.add(scrollView1);

};
afterSchool_announcement.open("GET","http://testdemo.web44.net/CHAT/afterSchool_announcement.php");
afterSchool_announcement.send();

var win10 = Ti.UI.createWindow({
	
	backgroundColor: 'white'
	
});

// after school tab
var tab2 = Ti.UI.createTab({
	title: 'AfterSchool',
	
	window: win10
});

//pulls up the tinyTykes logo from the folder
var image1 = Ti.UI.createImageView(
	{
		image: 'tinyTykes.JPG',
		width: '85%',
		height: '16%',
		top: '1%',
		left: '5%'	
	}
);

//pulls up the church hill academy logo from the folder
var image2 = Ti.UI.createImageView(
	{
		image: 'CHA.JPG',
		width: '85%',
		height: '16%',
		top: '1%',
		left: '5%'
		
	}
);

var tinyTykes_announcement = Titanium.Network.createHTTPClient();
tinyTykes_announcement.onload = function()
{
   var json = this.responseText;
    
    //alert(json); 
         
   var post1 = JSON.parse(json);
   
    var announcements = [];
   
 for(var i =0;i<post1.length;i++){ 
 	announcements[i] = post1[i];
}

var scrollView2 = Ti.UI.createScrollView({
  showVerticalScrollIndicator: true,
  showHorizontalScrollIndicator: false,
    top: '28%',
	bottom: '15%',
	left: '3%',
	right: '3%'
 
});

var view2 = Ti.UI.createView({
  backgroundColor:'white',

});

for(var i=0;i<100;i++)
{
	if(announcements[i]==null)
	{
		
	
          announcements[i]= '';
     }
     
}

var label_tinyTykes = Titanium.UI.createLabel
({
	left:'2%',
	right: '2%',
	top:'3%',
	color:'black',	
   
    text: announcements[0] + '\n\n' +  announcements[1] + '\n\n' +  announcements[2] + '\n\n' +  announcements[3] + '\n\n' +
     announcements[4] + '\n\n' +  announcements[5]+ '\n\n' +  announcements[6]+ '\n\n' +  announcements[7]+ '\n\n' +  announcements[8],
	
	font:{fontSize:'15dp',fontFamily:'Helvetica Neue'}
});


view2.add(label_tinyTykes);
scrollView2.add(view2);
win11.add(scrollView2);

};
tinyTykes_announcement.open("GET","http://testdemo.web44.net/CHAT/tinyTykes_announcement.php");
tinyTykes_announcement.send();


// tiny tykes tab
var tab3 = Ti.UI.createTab({
	title: 'Tiny Tykes',
	window: win11
});


var CHA_announcement = Titanium.Network.createHTTPClient();
CHA_announcement.onload = function()
{
   var json = this.responseText;
    
    //alert(json); 
         
   var post1 = JSON.parse(json);
   
    var announcements = [];
   
 for(var i =0;i<post1.length;i++){ 
 	announcements[i] = post1[i];
}
    
var scrollView3 = Ti.UI.createScrollView({
  showVerticalScrollIndicator: true,
  showHorizontalScrollIndicator: false,
    top: '28%',
	bottom: '15%',
	left: '3%',
	right: '3%'
 
});

var view3 = Ti.UI.createView({
  backgroundColor:'white',

});


for(var i=0;i<100;i++)
{
	if(announcements[i]==null)
	{
		
	
          announcements[i]= '';
     }
     
}

var announcements_CHA = Titanium.UI.createLabel
({
	left:'2%',
	right: '2%',
	top:'3%',
	color:'black',	
   
    text: announcements[0] + '\n\n' +  announcements[1] + '\n\n' +  announcements[2] + '\n\n' +  announcements[3] + '\n\n' +
     announcements[4] + '\n\n' +  announcements[5]+ '\n\n' +  announcements[6]+ '\n\n' +  announcements[7]+ '\n\n' +  announcements[8],
	
	font:{fontSize:'15dp',fontFamily:'Helvetica Neue'}
	
	
	
});

view3.add(announcements_CHA);
scrollView3.add(view3);
win12.add(scrollView3);
};
CHA_announcement.open("GET","http://testdemo.web44.net/CHAT/CHA_announcement.php");
CHA_announcement.send();


//CHA tab
var tab4 = Ti.UI.createTab({
	title: 'CHA',
	
	window: win12
});


// creates a label
var label = Titanium.UI.createLabel({
	color:'black',
	text:'I am a . . . ',
	font:{fontSize:'16dp',fontFamily:'Helvetica Neue',fontWeight:'bold'},
	top: '50.5%',
	left: '5%'
	
});



var view1 = Ti.UI.createView();

var view2 = Ti.UI.createView();

var view3 = Ti.UI.createView();

var view4 = Ti.UI.createView();



view1.add(image);


view3.add(image1);
view4.add(image2);
view2.add(image3);
win1.add(view1);
win1.add(label);


win1.add(label6); 
//win1.add(labelEmail);
win1.add(labelPhone);
win1.add(view_title);

win1.add(view_student);
win1.add(view_parent);
win1.add(view_volunteer);

win11.add(view3);


win12.add(view_title_CHA);
win12.add(view4);

win11.add(view_title2);

win10.add(view2);


win10.add(view_title3);




tabGroup.addTab(tab1);
tabGroup.addTab(tab4);
tabGroup.addTab(tab3);
tabGroup.addTab(tab2);

tabGroup.open();



 
 









