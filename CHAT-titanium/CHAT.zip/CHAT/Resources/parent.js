

var win_parent = Ti.UI.currentWindow;

var parent_Announcement = win_parent.parent_Announcement;

var view_title = Ti.UI.createView({
  backgroundColor:'#E9E9E9',
  top:'21%',
  height: '7%',
  width: '93%'

});

var Label1 = Ti.UI.createLabel({
    text : "PARENT ANNOUNCEMENTS",
    font:{
        fontSize : '15dp',
        fontWeight : 'bold',       
    },
    color : 'black',
    
    
    
});

view_title.add(Label1);



var image = Ti.UI.createImageView(
	{
		image: 'CHATlogo.jpg',
		width: '82%',
		height: '20%',
		top: '1%',
		left: '5%'
		
	}
);

image.addEventListener('click',function(e)
{
	Ti.UI.currentWindow.close();
		   
});

var announcements = Titanium.Network.createHTTPClient();
announcements.onload = function()
{
   var json = this.responseText;
    
    //alert(json); 
         
   var post1 = JSON.parse(json);
   
    var announcements = [];
   
 for(var i =0;i<post1.length;i++){ 
 	announcements[i] = post1[i];
}

var scrollView = Ti.UI.createScrollView({
  showVerticalScrollIndicator: true,
  showHorizontalScrollIndicator: false,
    top: '28%',
	bottom: '21%',
	left: '3%',
	right: '3%'
 
});

var view = Ti.UI.createView({
  backgroundColor:'white',

});

for(var i=0;i<100;i++)
{
	if(announcements[i]==null)
	{
		
	
          announcements[i]= '';
     }
     
}

var label_announcements = Titanium.UI.createLabel
({
	left:'2%',
	right: '2%',
	top:'3%',
	color:'black',	
   
    text: announcements[0] + '\n\n' +  announcements[1] + '\n\n' +  announcements[2] + '\n\n' +  announcements[3] + '\n\n' +
     announcements[4] + '\n\n' +  announcements[5]+ '\n\n' +  announcements[6]+ '\n\n' +  announcements[7]+ '\n\n' +  announcements[8],
	
	font:{fontSize:'15dp',fontFamily:'Helvetica Neue'}
	
	
	
});


view.add(label_announcements);
scrollView.add(view);
win_parent.add(scrollView);
};

announcements.open("GET","http://testdemo.web44.net/CHAT/parent_announcement.php");
announcements.send();

var view_parentFeedback = Ti.UI.createView();

var win2 = Ti.UI.createWindow({
	
	title: 'Parents feedback',
	backgroundColor: 'white'
	
});

// gives an option for parents to update their contact info
var button1 = Ti.UI.createButton
({
	title: 'Report phone number or address change',
	top: '82%',
	height: '7%',
	width: '93%',
	color:'#FAFAFA',
	backgroundColor: '#CDB482',
	
	font:{fontSize:'14dp',fontFamily:'Helvetica Neue',fontWeight: 'bold'},
	
});


// if the user clicks on "report address change button", a login page will appear
button1.addEventListener('click',function(e)
{
	var newWin1 = Ti.UI.createWindow({
			url: 'login.js',
			backgroundColor: 'white',
			title:'Parent Login'
		});
		
	 newWin1.open();
});


// gives an option for users to leave a feedback or question
var button3 = Ti.UI.createButton({
	title: 'Ask a question or leave a comment',
	top: '90%',
	height: '7%',
	width: '93%',
	color:'#FAFAFA',
	backgroundColor: '#CDB482',
	
	font:{fontSize:'14dp',fontFamily:'Helvetica Neue',fontWeight: 'bold'},
	
});

// opens up a new window if they click on the "ask a question" button
button3.addEventListener('click',function(e)
{
	win2.open();
});


var labelTitle = Titanium.UI.createLabel({
	color:'#020202',
	text:'Ask a Question or Leave a Comment:  ',
	font:{fontSize:'14dp', fontWeight:'bold'},
	left: '5%', 
	top: '11%'
	
});

var textField2 = Ti.UI.createTextArea({
  borderWidth: '2%',
  borderColor: 'black',
  backgroundColor : '#FAFAFA',
  color: '#888',
  font: {fontSize:'13dp', fontWeight:'bold'},
  textAlign: 'left',
  value: '',
  top: '15%', bottom : '30%',
  width: '90%'
 
});


var button4 = Titanium.UI.createButton({
    title:'Submit',
    color:'white',
    backgroundColor: '#3EA99F',
    top:'73%',
    width:'90%',
    height:'7%',
    borderRadius:1,
    borderColor: '#3EA99F',
    font:{fontFamily:'Helvetica Neue',fontWeight:'bold',fontSize:'15dp'},
   
});

button4.addEventListener('click',function(e)
{
	 var emailDialog = Ti.UI.createEmailDialog();

     emailDialog.subject = "Message from Parent";
      emailDialog.toRecipients = ['info@chatrichmond.org'];
     emailDialog.setMessageBody(textField2.value);
     emailDialog.open();
	
	
	win2.close();
});

var button5 = Titanium.UI.createButton({
    title:'Close',
    color:'white',
    backgroundColor: '#3EA99F',
    top:'83%',
    width:'90%',
    height:'7%',
    borderRadius:1,
    borderColor: '#3EA99F',
    font:{fontFamily:'Helvetica Neue',fontWeight:'bold',fontSize:'15dp'},
   
});

button5.addEventListener('click',function(e)
{
	win2.close();
});

win_parent.add(image);

win_parent.add(view_title);


win_parent.add(button1);
win_parent.add(button3);

view_parentFeedback.add(textField2);
view_parentFeedback.add(button4);
view_parentFeedback.add(button5);
view_parentFeedback.add(labelTitle);

win2.add(view_parentFeedback);





