var Cloud = require('ti.cloud');

var tabGroup = Titanium.UI.createTabGroup();

var win = Titanium.UI.currentWindow;

var tab1 = Titanium.UI.createTab
({
    window: win
});



var label_text = Titanium.UI.createLabel({
	color:'#020202',
	text:'Please enter you email address: ',
	font:{fontSize:'15dp'},
	top: '4%',
	left: '6%'
	
});

win.add(label_text);

var email = Titanium.UI.createTextField({

    top:'8.5%',  
    width:'90%',
    height:'7%',
    hintText:'email',
    color: 'black',
    borderColor: '#C0C0C0',
    font:{fontFamily:'Helvetica Neue',fontSize:'14dp',fontColor: 'black'},
    borderStyle:Titanium.UI.INPUT_BORDERSTYLE_ROUNDED
    
});
win.add(email);


function randomXToY(minVal,maxVal)
{ var randVal = minVal+(Math.random()*(maxVal-minVal)); 
return Math.round(randVal); }

var random = randomXToY(0,89898989212);

var random1= random + 237829;

var loginReq = Titanium.Network.createHTTPClient();

loginReq.onload = function()
{
    var json = this.responseText; 
    
    var response = JSON.parse(json);
    
    
        var USERNAME = response.PARENT_USERNAME;
        var PASSWORD = response.PASSWORD;
        var EMAIL = response.EMAIL;

 if(USERNAME!=null)
 {
 //	alert('success');
 	
 	
 	Cloud.Emails.send({
 		 		
			template : 'default',
			recipients : EMAIL,
			USERNAME : USERNAME,
			PASSWORD : random1
		}, function(e) {
			if (e.success) {
				alert('Username/reset code is sent to your email address');
			} else {
				alert('Error:\n' + ((e.error && e.message) || JSON.stringify(e)));
			}
		});
 }
 else{
 	alert('Email address not found, try different email!');
 }
};

var submitBtn = Titanium.UI.createButton({
    title:'Submit',
    color:'white',
    backgroundColor: '#3EA99F',
    top:'20.5%',
    width:'90%',
    height:'9%',
    borderRadius:1,
    borderColor: '#3EA99F',
    font:{fontFamily:'Helvetica Neue',fontWeight:'bold',fontSize:'15dp'},   
});

win.add(submitBtn);

var labelReset = Titanium.UI.createLabel({
	color:'#020202',
	text:'Please check your email for the reset code: ',
	font:{fontSize:'15dp'},
	top: '45%',
	left: '6%'
	
});

win.add(labelReset);

var code = Titanium.UI.createTextField({

    top:'50%',  
    width:'90%',
    height:'7%',
    hintText:'Reset code',
    color: 'black',
    borderColor: '#C0C0C0',
    font:{fontFamily:'Helvetica Neue',fontSize:'14dp',fontColor: 'black'},
    borderStyle:Titanium.UI.INPUT_BORDERSTYLE_ROUNDED
    
});
win.add(code);

var codeBtn = Titanium.UI.createButton({
    title:'Submit',
    color:'white',
    backgroundColor: '#3EA99F',
    top:'60%',
    width:'90%',
    height:'9%',
    borderRadius:1,
    borderColor: '#3EA99F',
    font:{fontFamily:'Helvetica Neue',fontWeight:'bold',fontSize:'15dp'},
   
});

win.add(codeBtn);

codeBtn.addEventListener('click',function(e)
{
   
  
    if(random1!=code.value)
    {
    	alert('INCORRECT CODE');
    }
    
    else
    {
    	 var winNext = Ti.UI.createWindow({
        width : 'auto',
        height: 'auto',
         backgroundColor : '#FFFFFF',
          url  : 'parentPassword.js'
        });
        
         winNext.EMAIL = email.value;
        
       
        
       winNext.open();
    }
   
});


submitBtn.addEventListener('click',function(e)
{
   
  
    loginReq.open("POST","http://testdemo.web44.net/CHAT/parentForgot.php");
       
        var params =
        {
            EMAIL: email.value  
        };
        loginReq.send(params);
   
});


tabGroup.addTab(tab1);

if(Ti.Platform.name === 'android')
{
  var backBtn = Titanium.UI.createButton
  ({
      title:'Back',
      style:Titanium.UI.SystemButtonStyle.BORDERED     
  });  
}

else
{
var backBtn = Titanium.UI.createButton
  ({
      title:'Back',    
  });  

}
	

win.leftNavButton = backBtn;	
  
backBtn.addEventListener('click',function(e)
{
    tabGroup.close();
});

tabGroup.open();