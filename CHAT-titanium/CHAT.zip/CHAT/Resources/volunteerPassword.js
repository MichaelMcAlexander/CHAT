var tabGroup = Titanium.UI.createTabGroup();
var win = Ti.UI.currentWindow;

var tab1 = Titanium.UI.createTab
({
    window: win
});

var EMAIL = win.EMAIL;


var labelReset = Titanium.UI.createLabel({
	color:'#020202',
	text:'Enter Your New Password',
	font:{fontSize:'16dp'},
	top: '5%',
	
	
});

win.add(labelReset);

var password = Titanium.UI.createTextField({

    top:'14%',  
    width:'90%',
    height:'7%',
    hintText:'New Password',
    passwordMask:true,
    color: 'black',
    borderColor: '#C0C0C0',
    font:{fontFamily:'Helvetica Neue',fontSize:'14dp',fontColor: 'black'},
    borderStyle:Titanium.UI.INPUT_BORDERSTYLE_ROUNDED
    
});
win.add(password);

var password2 = Titanium.UI.createTextField({

    top:'27%',  
    width:'90%',
    height:'7%',
    hintText:'Confirm New Password',
    passwordMask:true,
    color: 'black',
    borderColor: '#C0C0C0',
    font:{fontFamily:'Helvetica Neue',fontSize:'14dp',fontColor: 'black'},
    borderStyle:Titanium.UI.INPUT_BORDERSTYLE_ROUNDED
    
});
win.add(password2);


var submitBtn = Titanium.UI.createButton({
    title:'Submit',
    color:'white',
    backgroundColor: '#3EA99F',
    top:'45%',
    width:'90%',
    height:'9%',
    borderRadius:1,
    borderColor: '#3EA99F',
    font:{fontFamily:'Helvetica Neue',fontWeight:'bold',fontSize:'15dp'},
   
});

win.add(submitBtn);

var loginReq = Titanium.Network.createHTTPClient();

submitBtn.addEventListener('click',function(e)
{
   if(password.value!=password2.value)
   {
   	alert('Password do not match');
   }
   
   else
   {
   	  loginReq.open("POST","http://testdemo.web44.net/CHAT/changeVolunteer.php");
       
       
        var params =
        {
            EMAIL: EMAIL, 
            PASSWORD: Ti.Utils.sha1(password.value)    
        };
        loginReq.send(params);
        
      alert('Updated Successfully!');
   }
   
   
});


tabGroup.addTab(tab1);

if(Ti.Platform.name === 'android')
{
  var backBtn = Titanium.UI.createButton
  ({
      title:'Back',
      style:Titanium.UI.SystemButtonStyle.BORDERED     
  });  
}

else
{
 
 var backBtn = Titanium.UI.createButton
  ({
      title:'Back',    
  });  
	
}
win.leftNavButton = backBtn;	
  
backBtn.addEventListener('click',function(e)
{
    tabGroup.close();  
});

tabGroup.open();




