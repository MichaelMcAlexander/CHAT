var winNext = Ti.UI.currentWindow;

var id = winNext.id;


var name = winNext.name;
var lastname = winNext.lastname;
var address = winNext.address;
var city = winNext.city;
var state = winNext.state;
var zipcode = winNext.zipcode;
var phone = winNext.phone;
var email = winNext.email;

var view_title = Ti.UI.createView({
  backgroundColor:'#E9E9E9',
  top:'5%',
  height: '7%',
  width: '93%'

});

var Label1 = Ti.UI.createLabel({
    text : "Contact Information",
    font:{
        fontSize : '16dp',
        fontWeight : 'bold',
        fontFamily:'Helvetica Neue'
        
    },
    color : 'black',  
});

view_title.add(Label1);
winNext.add(view_title);

var first = Ti.UI.createLabel({
	
	top:'14%',
	
	left: '9%',
	height: 'auto',
	color: 'black',
    text : 'First Name',
    font: {
    fontSize : '14dp',
    fontFamily:'Helvetica Neue',
     
    }
});
winNext.add(first);

var last = Ti.UI.createLabel({
	
	top:'14%',
	
	left: '54%',
	height: 'auto',
	color: 'black',
    text : 'Last Name',
    font: {
    fontSize : '14dp',
    fontFamily:'Helvetica Neue',
    //fontWeight: 'bold'
    }
});
winNext.add(last);

var lblFirstName = Ti.UI.createLabel({
  top  : '17%',
  width : '30%',
  left: '3%',
  height : '4%',
  color: 'black',
  text : name,
  textAlign :'center',
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 
 winNext.add(lblFirstName);

var lblLastName = Ti.UI.createLabel({
  top  : '17%',
  width : '50%',
  left: '40%',
  height : '4%',
  color: 'black',
  text : lastname,
  textAlign :'center',
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 
winNext.add(lblLastName);

var lblAddress = Ti.UI.createLabel({
  top  : '25%',
  left: '9%', 
  color: 'black',
  text : 'Address',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lblAddress);
 
 
 var lbl_address = Ti.UI.createLabel({
  top  : '28%',
  width : '90%',
  left: '3%',
  height : '4%',
  color: 'black',
  text : "   " + address,
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lbl_address);
 
 var lblCity = Ti.UI.createLabel({
  top  : '35%',
  left: '9%',
  height : '4%',
  color: 'black',
  text : 'City',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lblCity);
 
 var lbl_city = Ti.UI.createLabel({
  top  : '39%',
  width : '30%',
  left: '3%',
  height : '4%',
  color: 'black',
  text : "  " + city,
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lbl_city);
 
 
 
 var lblState = Ti.UI.createLabel({
  top  : '35%',
  left: '43%',
  height : '4%',
  color: 'black',
  text : 'State',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lblState);
 
 var lbl_state = Ti.UI.createLabel({
  top  : '39%',
  width : '30%',
  left: '38%',
  height : '4%',
  color: 'black',
  text : "  " + state,
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lbl_state);
 
 var lblZipcode = Ti.UI.createLabel({
  top  : '35%',
  left: '75%',
  height : '4%',
  color: 'black',
  text : 'Zip Code',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lblZipcode);
 
 var lbl_zipcode = Ti.UI.createLabel({
  top  : '39%',
  width : '20%',
  left: '73%',
  height : '4%',
  color: 'black',
  text : "  " + zipcode,
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lbl_zipcode);
 
 var lblPhone = Ti.UI.createLabel({
  top  : '50%',
  left: '9%',
  height : '4%',
  color: 'black',
  text : 'Phone',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lblPhone);
 
  var lbl_phone = Ti.UI.createLabel({
  top  : '54%',
  width : '30%',
  left: '3%',
  height : '4%',
  color: 'black',
  text : phone,
  textAlign: 'center',
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lbl_phone);
 
 var lblEmail = Ti.UI.createLabel({
  top  : '50%',
  left: '60%',
  height : '4%',
  color: 'black',
  text : 'Email',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lblEmail);
 
  var lbl_email = Ti.UI.createLabel({
  top  : '54%',
  width : '57%',
  left: '38%',
  height : '4%',
  color: 'black',
  text : email,
  textAlign: 'center',
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 winNext.add(lbl_email);
 
 var closeBtn = Titanium.UI.createButton({
    title:'Close',
    color: 'black',
    top:'70%',
    left: '18%',
    width:'25%',
    height:'8%',
    borderRadius:1,
    borderColor: '#C0C0C0',
    font:{fontFamily:'Arial',fontSize:'16dp'}
});

var editBtn = Titanium.UI.createButton({
    title:'Edit',
    color: 'black',
    top:'70%',
    left: '52%',
    width:'25%',
    height:'8%',
    borderRadius:1,
    borderColor: '#C0C0C0',
    font:{fontFamily:'Arial',fontSize:'16dp'}
});

winNext.add(closeBtn);
winNext.add(editBtn);

closeBtn.addEventListener('click',function(e)
{
	winNext.close();
});
 
 editBtn.addEventListener('click',function(e)
{
	var editWin = Ti.UI.createWindow
	({
		title:'Update Info',
        width : 'auto',
        height: 'auto',
         backgroundColor : '#FFFFFF',
          url  : 'editVolunteer.js'
   });
       
        editWin.id = id;
        editWin.name = name;
        editWin.lastname = lastname;
        editWin.address = address;
        editWin.city = city;
        editWin.state = state;
        editWin.zipcode = zipcode;
        editWin.phone = phone;
        editWin.email = email; 
        
        
        
        editWin.open();
	
});
 
