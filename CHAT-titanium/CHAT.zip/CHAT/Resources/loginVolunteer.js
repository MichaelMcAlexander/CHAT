var tabGroup = Titanium.UI.createTabGroup();

var win = Titanium.UI.currentWindow;

var tab1 = Titanium.UI.createTab
({
    window: win
});

var imageLogo = Ti.UI.createImageView(
	{
		image: 'CHATlogo.jpg',
		width: '84%',
		height: '20%',
		top: '6%',	
	}
);
win.add(imageLogo);


 
var username = Titanium.UI.createTextField({

    top:'35%',  
    width:'90%',
    height:'8%',
    hintText:'Username',
    color: 'black',
    borderColor: '#C0C0C0',
    font:{fontFamily:'Helvetica Neue',fontSize:'14dp',fontColor:'black'},
    borderStyle:Titanium.UI.INPUT_BORDERSTYLE_ROUNDED
    
});
win.add(username);
 
var password = Titanium.UI.createTextField({
    
    top:'48%',
    width:'90%',
    height:'8%',
    hintText:'Password',
    passwordMask:true,
    borderColor: '#C0C0C0',
    font:{fontFamily:'Helvetica Neue',fontSize:'14dp'},
    borderStyle:Titanium.UI.INPUT_BORDERSTYLE_ROUNDED
   
});

win.add(password);
 
var loginBtn = Titanium.UI.createButton({
    title:'Login',
    color:'white',
    backgroundColor: '#3EA99F',
    top:'62%',
    width:'90%',
    height:'9%',
    borderRadius:1,
    borderColor: '#3EA99F',
    font:{fontFamily:'Helvetica Neue',fontWeight:'bold',fontSize:'15dp'},
   
});

win.add(loginBtn);

var helpBtn = Titanium.UI.createButton({
    title:'Forgot Username/Password',
    color:'white',
    backgroundColor: '#3EA99F',
    top:'75%',
    width:'90%',
    height:'9%',
    borderRadius:1,
    borderColor: '#3EA99F',
    font:{fontFamily:'Helvetica Neue',fontWeight:'bold',fontSize:'15dp'},
   
});

win.add(helpBtn);

helpBtn.addEventListener('click',function(e)
{
    var win_parent = Ti.UI.createWindow({
			url: 'volunteerHelp.js',
			backgroundColor: 'white',
			title:'Forgot Login'
		});
	
		
		tab1.open(win_parent);	   
});


var loginReq = Titanium.Network.createHTTPClient();

loginReq.onload = function()
{
    var json = this.responseText; 
    

    
    var response = JSON.parse(json);
    if (response.logged == true)
    {
      
       var winNext = Ti.UI.createWindow({
        width : 'auto',
        height: 'auto',
         backgroundColor : '#FFFFFF',
          url  : 'volunteerInfo.js'
        });

        winNext.id = response.VOL_ID;
        winNext.name = response.FIRSTNAME;
        winNext.lastname = response.LASTNAME;
        winNext.address = response.ADDRESS;
        winNext.city = response.CITY;
        winNext.state = response.STATE;
        winNext.zipcode = response.ZIPCODE;
        winNext.phone = response.PHONE_NUM;
        winNext.email = response.EMAIL; 
        winNext.username = username.value;
        winNext.password = Ti.Utils.sha1(password.value);
        
        winNext.open();
       
    }
    else
    {
        alert(response.message);
    }
};
 

 
loginBtn.addEventListener('click',function(e)
{
    if (username.value != '' && password.value != '')
    {
        
       
       
       loginReq.open("POST","http://testdemo.web44.net/CHAT/volunteerLogin.php");
       
        var params =
        {
            VOL_USERNAME: username.value, 
            VOL_PASSWORD: Ti.Utils.sha1(password.value)    
        };
        loginReq.send(params);
    }
    else
    {
        alert("Username/Password are required");
    }
});



tabGroup.addTab(tab1);

if(Ti.Platform.name === 'android')
{
  var backBtn = Titanium.UI.createButton
  ({
      title:'Back',
      style:Titanium.UI.SystemButtonStyle.BORDERED     
  });  
}

else
{
var backBtn = Titanium.UI.createButton
  ({
      title:'Back',    
  });  

}
	

win.leftNavButton = backBtn;	
  
backBtn.addEventListener('click',function(e)
{
    tabGroup.close();
});

tabGroup.open();