var tabGroup = Titanium.UI.createTabGroup();

var editWin = Ti.UI.currentWindow;

var id = editWin.id;
var name = editWin.name;
var lastname = editWin.lastname;
var address = editWin.address;
var city = editWin.city;
var state = editWin.state;
var zipcode = editWin.zipcode;
var phone = editWin.phone;
var email = editWin.email;


var first = Ti.UI.createLabel({
	
	top:'6%',
	
	left: '9%',
	height: 'auto',
	color: 'black',
    text : 'First Name',
    font: {
    fontSize : '14dp',
    fontFamily:'Helvetica Neue',
     
    }
});
editWin.add(first);

var last = Ti.UI.createLabel({
	
	top:'6%',
	
	left: '54%',
	height: 'auto',
	color: 'black',
    text : 'Last Name',
    font: {
    fontSize : '14dp',
    fontFamily:'Helvetica Neue',
    //fontWeight: 'bold'
    }
});
editWin.add(last);

var lblFirstName = Ti.UI.createLabel({
  top  : '10%',
  width : '30%',
  left: '3%',
  height : '6%',
  color: 'black',
  text : name,
  textAlign :'center',
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 
editWin.add(lblFirstName);

var lblLastName = Ti.UI.createLabel({
  top  : '10%',
  width : '50%',
  left: '40%',
  height : '6%',
  color: 'black',
  text : lastname,
  textAlign :'center',
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 
editWin.add(lblLastName);

var lblAddress = Ti.UI.createLabel({
  top  : '20%',
  left: '9%', 
  color: 'black',
  text : 'Address',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
editWin.add(lblAddress);
 
 
 var lbl_address = Ti.UI.createTextField({
  top  : '24%',
  width : '90%',
  left: '3%',
  height : '6%',
  color: 'black',
  hintText : address,
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 editWin.add(lbl_address);
 
 var lblCity = Ti.UI.createLabel({
  top  : '34%',
  left: '3%',
  height : 'auto',
  color: 'black',
  text : 'City',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 editWin.add(lblCity);
 
 var lbl_city = Ti.UI.createTextField({
  top  : '38%',
  width : '30%',
  left: '3%',
  height : '6%',
  color: 'black',
  hintText : city,
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 editWin.add(lbl_city);
 
 
 
 var lblState = Ti.UI.createLabel({
  top  : '34%',
  left: '43%',
  height : 'auto',
  color: 'black',
  text : 'State',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 editWin.add(lblState);
 
 var lbl_state = Ti.UI.createTextField({
  top  : '38%',
  width : '30%',
  left: '38%',
  height : '6%',
  color: 'black',
  hintText : state,
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
editWin.add(lbl_state);
 
 var lblZipcode = Ti.UI.createLabel({
  top  : '34%',
  left: '75%',
  height : 'auto',
  color: 'black',
  text : 'Zip Code',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
editWin.add(lblZipcode);
 
 var lbl_zipcode = Ti.UI.createTextField({
  top  : '38%',
  width : '20%',
  left: '73%',
  height : '6%',
  color: 'black',
  hintText : zipcode,
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 editWin.add(lbl_zipcode);
 
 var lblPhone = Ti.UI.createLabel({
  top  : '47%',
  left: '9%',
  height : 'auto',
  color: 'black',
  text : 'Phone',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 editWin.add(lblPhone);
 
  var lbl_phone = Ti.UI.createTextField({
  top  : '51%',
  width : '30%',
  left: '3%',
  height : '6%',
  color: 'black',
  hintText : phone,
  textAlign: 'center',
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
 editWin.add(lbl_phone);
 
 var lblEmail = Ti.UI.createLabel({
  top  : '47%',
  left: '60%',
  height : 'auto',
  color: 'black',
  text : 'Email',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
editWin.add(lblEmail);
 
  var lbl_email = Ti.UI.createTextField({
  top  : '51%',
  width : '57%',
  left: '38%',
  height : '6%',
  color: 'black',
  hintText : email,
  textAlign: 'center',
  
  borderColor: '#C0C0C0',
  font: {
  fontSize : '14dp',
  fontFamily:'Helvetica Neue' 
  }
 });
editWin.add(lbl_email);

var createReq = Titanium.Network.createHTTPClient();

var submitBtn = Titanium.UI.createButton({
    title:'Submit',
    color:'#6E6E6E',
    left:'3%',
    backgroundColor: '#E9E9E9',
    top:'70%',
    width:'92%',
    height:'7%',
    borderRadius:1,
    borderColor: '#E9E9E9',
    font:{fontFamily:'Helvetica Neue',fontWeight:'bold',fontSize:'15dp'},
   
});

editWin.add(submitBtn);




	createReq.open("POST","http://testdemo.web44.net/CHAT/parentUpdate.php");
	
submitBtn.addEventListener('click',function(e)
{
	
	
	
                var params = {
                	
                	PARENT_ID :id,
                	LASTNAME: lastname,    	
                    FIRSTNAME: name,
                    ADDRESS : lbl_address.value,
                    CITY : lbl_city.value,
                    STATE: lbl_state.value,
                    ZIPCODE: lbl_zipcode.value,
                    PHONE: lbl_phone.value,
                    EMAIL : lbl_email.value
                    
                };
                createReq.send(params);
                
                 alert("Updated Successfully!");
		
//	tabGroup.close();
});

var tab1 = Titanium.UI.createTab
({
    window: editWin
});

tabGroup.addTab(tab1);


if(Ti.Platform.name === 'android')
{
  var backBtn = Titanium.UI.createButton
  ({
      title:'Back',
      style:Titanium.UI.SystemButtonStyle.BORDERED     
  });  
}

else
{
 
 var backBtn = Titanium.UI.createButton
  ({
      title:'Back',    
  });  
	
}
Ti.UI.currentWindow.leftNavButton = backBtn;	
  
backBtn.addEventListener('click',function(e)
{
    tabGroup.close();  
});

tabGroup.open();
