
var win_student = Ti.UI.currentWindow;






var win_student = Ti.UI.currentWindow;

 
 var student_Announcement;


    

var view_title = Ti.UI.createView({
  backgroundColor:'#E9E9E9',
  top:'19%',
  height: '7%',
  width: '93%'

});

var Label1 = Ti.UI.createLabel({
    text : "STUDENT ANNOUNCEMENTS",
    font:{
        fontSize : '15dp',
        fontWeight : 'bold'
    },
    color : 'black',
    
});

view_title.add(Label1);



var image = Ti.UI.createImageView(
	{
		image: 'CHATlogo.jpg',
		width: '80%',
		height: '18%',
		top: '1%',
		left: '5%'
		
	}
);

image.addEventListener('click',function(e)
{
	Ti.UI.currentWindow.close();
		   
});

var announcements = Titanium.Network.createHTTPClient();
announcements.onload = function()
{
   var json = this.responseText;
    
    //alert(json); 
         
   var post1 = JSON.parse(json);
   
    var announcements = [];
   
 for(var i =0;i<post1.length;i++){ 
 	announcements[i] = post1[i];
}

var scrollView = Ti.UI.createScrollView({
  showVerticalScrollIndicator: true,
  showHorizontalScrollIndicator: false,
    top: '28%',
	bottom: '2%',
	left: '3%',
	right: '3%'
 
});

var view = Ti.UI.createView({
  backgroundColor:'white',

});



for(var i=0;i<100;i++)
{
	if(announcements[i]==null)
	{
		
	
          announcements[i]= '';
     }
     
}

var label_announcements = Titanium.UI.createLabel
({
	left:'2%',
	right: '2%',
	top:'3%',
	color:'black',	
   
    text: announcements[0] + '\n\n' +  announcements[1] + '\n\n' +  announcements[2] + '\n\n' +  announcements[3] + '\n\n' +
     announcements[4] + '\n\n' +  announcements[5]+ '\n\n' +  announcements[6]+ '\n\n' +  announcements[7]+ '\n\n' +  announcements[8],
	
	font:{fontSize:'15dp',fontFamily:'Helvetica Neue'}
	
	
	
});


view.add(label_announcements);
scrollView.add(view);
win_student.add(scrollView);

};
announcements.open("GET","http://testdemo.web44.net/CHAT/student_announcement.php");
announcements.send();


win_student.add(image);

win_student.add(view_title);




 

