<?php

// Connect to the database(host, username, password)


$conn = mysql_connect("216.224.168.11:3306", "root", "vcuchat2015");


if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}

mysql_select_db('chat');


$EMAIL = $_POST['EMAIL'];
$PASSWORD = $_POST['PASSWORD'];





    $query = mysql_query("UPDATE parents SET PARENT_PASSWORD = '{$PASSWORD}' WHERE EMAIL = '$EMAIL'");



        
?>
