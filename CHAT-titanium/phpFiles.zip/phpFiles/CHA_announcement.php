<?php

// Connect to the database(host, username, password)

$con = mysql_connect("216.224.168.11:3306", "root", "vcuchat2015");

if (!$con)
{
    echo "Failed to make connection.";
    exit;
}
$db = mysql_select_db('chat');
if (!$db)
{
    echo "Failed to select db.";
    exit;
}
 


 


$sql = "select * from announcements  where PROGRAM_ID = 5 AND ANNOUNCEMENT_DONE = 0 ORDER BY ID DESC";
$result = mysql_query($sql);
 $response = Array();

while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
    
    $response[] =  $row['ANNOUNCEMENT_MESSAGE'];
    
}


 echo json_encode($response);






 
 

  

?>